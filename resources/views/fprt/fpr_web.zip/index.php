﻿<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Fingerprint WebAPI Test App</title>
   
    <link rel="stylesheet" href="css/bootstrap-min.css">
    <link rel="stylesheet" href="app.css" type="text/css" />
</head>
<body>
    <div id="Container">

    <ul>
    <li><a href="enroll.php">Enroll</a></li>
    <li><a href="verify.php">Verify</a></li>
    </ul>  

    </div>


        
</body>
</html>
