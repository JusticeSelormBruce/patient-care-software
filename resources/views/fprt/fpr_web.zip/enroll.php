<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Fingerprint Enroll</title>
   
    <link rel="stylesheet" href="css/bootstrap-min.css">
    <link rel="stylesheet" href="app.css" type="text/css" />
</head>
<body>
    <div id="Container">
        <p id="status"></p>
        <p id="deviceInfo"></p>
        <p id="scanner_quality"></p>
    
        <button onclick="startScan()">Scan</button>  
        <form action="savedata.php" method="POST">
            <input type="text" name="name" placeholder="Name"/>
            <input type="text" name="address" placeholder="address"/>
            <!--TODO this must be in your registration form-->
            <input type="hidden" name="fingerprint_image" id="fingerprint_image" >
            <input type="submit" value="Submit"/>
        </form>

    </div>

    <script src="lib/jquery.min.js"></script> 
    <script src="lib/bootstrap.min.js"></script>
    <script src="scripts/es6-shim.js"></script>
    <script src="scripts/websdk.client.bundle.min.js"></script>
    <script src="scripts/fingerprint.sdk.min.js"></script>
    <script src="app.js"></script>
    <script>
         setUpForEnrollment();
    </script>
    
        
</body>
</html>
