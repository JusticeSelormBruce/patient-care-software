<?php
//TODO get fingerprint data
$fingerprint_image = $_POST['fingerprint_image'];
//some other data;
$name = $_POST['name'];
$address = $_POST['address'];

//TODO start some transaction
//TODO save your data in transaction by don't commit ---- $someContext->save();
$user_id = 1;//TODO get some last insert id;

//POST to the JAVA server
$request_url="http://localhost:8000/enroll";
$request = array(
    'userId'=> $user_id."",
    'imgSrc'=>  $fingerprint_image,
    'imgSrc2'=>  $fingerprint_image,//some other finger scan
    'format'=>'wsq'
);

$request=json_encode($request);

//TODO comment out
var_dump($request);

$ch =  curl_init($request_url);
curl_setopt( $ch, CURLOPT_POST, true );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ch, CURLOPT_POSTFIELDS, $request);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
    'Cache-Control: no-cache',
    'Content-Type: application/json',
));

$result = curl_exec($ch);
//TODO decode result for {status:0} //enrollment completed
$decodedresult = json_decode('{"status":0}');
if($decodedresult->status==0){
//TODO commit transantion
}
else{
    //rollback
}