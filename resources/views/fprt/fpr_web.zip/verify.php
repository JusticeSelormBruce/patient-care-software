<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Fingerprint Enroll</title>
   
    <link rel="stylesheet" href="css/bootstrap-min.css">
    <link rel="stylesheet" href="app.css" type="text/css" />
</head>
<body>
    <div id="Container">
        <div class="" style="display:none;">
            
            <p id="deviceInfo"></p>
           
        </div>
        <p id="status"></p>
        <p id="scanner_quality"></p>
       
       

    </div>

    <script src="lib/jquery.min.js"></script> 
    <script src="lib/bootstrap.min.js"></script>
    <script src="scripts/es6-shim.js"></script>
    <script src="scripts/websdk.client.bundle.min.js"></script>
    <script src="scripts/fingerprint.sdk.min.js"></script>
    <script src="app.js"></script>
    <script>
         setUpForVerification();
    </script>
    
        
</body>
</html>
